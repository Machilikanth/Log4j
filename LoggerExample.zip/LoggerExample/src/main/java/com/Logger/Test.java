package com.Logger;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Test {
	private static final Logger log =LogManager.getLogger(Test.class);

	public static void main(String[] args) {
		processdata();
	}
	public static void  processdata()
	{
		log.trace("In trace");
		log.error("In error");
		log.fatal("in fatal");
		log.debug("In debug");
		log.info("In info");
		log.warn("In warn");
	}
		
	}
	


